const settings = {
  packname: 'ʟᴀᴅʏ ʙᴇʟʟᴀ ᴠ3',
  author: '‎',
  botName: "ʟᴀᴅʏ ʙᴇʟʟᴀ ᴠ3",
  botOwner: 'sɴᴏᴡʙɪʀᴅ', // Your name
  ownerNumber: '263780145644', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "3.0.0",
  updateZipUrl: "https://github.com/SNOWBIRD0074/Lady-Bella2/archive/refs/heads/main.zip",
};

module.exports = settings;
